﻿
int krystals = 50;
int gold, howManyBuy, whatToDo;
Console.WriteLine("Привет!");
Console.WriteLine("Ты находишься в лавке торговки кристалами. Ты можешь обменять золото на кристаллы по курсу 1 кристалл = 5 золота.");
Console.WriteLine(" Количество кристаллов у торговки:{0}", krystals);
Console.WriteLine("Но с начала, введи сколько у тебя золота!");
howManyGold:
Console.WriteLine("Количество твоего золота: ");
try
{
    gold = Convert.ToInt32(Console.ReadLine());
    while (gold<5)
    {
        Console.WriteLine("Число золота должно быть минимум равно пяти. Перепроверь вводимое колличество золота и попробуй ещё раз!");
        goto howManyGold;
    }
}
catch 
{
    Console.WriteLine("Что-то пошло не так. Перепроверь вводимое колличество золота и попробуй ещё раз!");
    goto howManyGold;
}
howManyKrystals:
Console.WriteLine("Количество твоего золота: {0}. Количество кристаллов у торговки:{1}", gold, krystals);
Console.WriteLine("Сколько кристаллов ты хочешь купить? ");
try
{
    howManyBuy = Convert.ToInt32(Console.ReadLine());
    while (howManyBuy<=0)
    {
        Console.WriteLine("Количество кристаллов должно быть больше нуля. Перепроверь вводимое колличество кристаллов и попробуй ещё раз!");
        goto howManyKrystals; 
    }
    while (howManyBuy >50)
    {
        Console.WriteLine("Количество кристаллов должно быть меньше пятидесяти. Перепроверь вводимое колличество кристаллов и попробуй ещё раз!");
        goto howManyKrystals;
    }
}
catch
{
    Console.WriteLine("Что-то пошло не так. Перепроверь вводимое колличество кристаллов и попробуй ещё раз!");
    goto howManyKrystals;
}

while(gold- howManyBuy * 5 < 0)
{
    Console.WriteLine("У тебя недостаточно золота. Перепроверь вводимое колличество кристаллов и попробуй ещё раз!");
    goto howManyKrystals;
}
gold = gold - howManyBuy * 5;
krystals = krystals - howManyBuy;
whatToDoNow:
Console.WriteLine("Количество твоего золота: {0}. Количество кристаллов у торговки:{1}", gold, krystals);
Console.WriteLine("Хочешь купить ещё(1), начать с начала(2) или выйти(3)?");
try
{
    whatToDo= Convert.ToInt32(Console.ReadLine());
    while (whatToDo == 1)
    {
        Console.WriteLine("Можешь купить ещё кристаллов!");
        goto howManyKrystals;
    }
    while (whatToDo ==2)
    {
        Console.WriteLine("Начинаем с начала!");
        goto howManyGold;
    }
    while (whatToDo == 3)
    {
     
        goto end;
    }
}
catch 
{
    Console.WriteLine("Что-то пошло не так. Перепроверь вводимое число и попробуй ещё раз!");
    goto whatToDoNow;
}
end:
Console.WriteLine("Заканчиваем!");