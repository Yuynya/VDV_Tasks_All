﻿Console.WriteLine("Привет!");
Console.WriteLine("Эта программа выполняется до тех пор, пока ты не напишешь 'exit'");
string word="";
while (word != "exit")
{
    Console.WriteLine("......");
    Console.WriteLine("Введити слово");
   word=Console.ReadLine();
}
Console.WriteLine("Конец программы");
