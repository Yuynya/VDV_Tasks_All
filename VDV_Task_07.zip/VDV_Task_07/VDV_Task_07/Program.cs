﻿int howMany;
Console.WriteLine("Это праграмма перемешивания массива!");
Console.WriteLine("Введите число и мы создим массив из случайных чисел такого размера, а затем его перемешаем");
HowMany:
Console.WriteLine("Введите число");
try
{
    howMany = Convert.ToInt32(Console.ReadLine());
    if (howMany <= 2)
    {
        Console.WriteLine("Число слишком маленькое, введите число больше двух.");
        goto HowMany;
    }
}
catch
{
    Console.WriteLine("Что-то не так. Проверьте вводимое чило и попробуйте ещё раз");
    goto HowMany;
}
int[] array = new int[howMany];
Random rand = new Random();
for (int y = 0; y < howMany; y++)
{
    array[y] = rand.Next();
}
Console.WriteLine("Выводим массив в столбик");
foreach (int i in array)
{
    Console.WriteLine(i);
}

Shuffle( ref array);
Console.WriteLine();
Console.WriteLine("Выводим перемешанный массив в столбик");
foreach (int i in array)
{
    Console.WriteLine(i );
}
void Shuffle( ref int []array)
{
    Random rand = new Random();
    for(int i = howMany-1; i>=1; i--)
    {
        int j=rand.Next(0,i);
        int help=array[i];
        array[i] = array[j];
        array[j] = help;
    }
}