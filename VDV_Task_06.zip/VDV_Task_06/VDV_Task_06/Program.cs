﻿using System.Collections.Generic;

int whatToDo=0;
int index=0;
string name, secondName, jobNotArray;
List<string> job = new List<string>();
List<string> FIO = new List<string>();
Console.WriteLine("Это программа управления списком сотрудниц!");
while (whatToDo!=5)
{
    try
    {
        Console.WriteLine(" ");
        Console.WriteLine("------------------------------");
        Console.WriteLine("1. Добавить сотрудницу");
        Console.WriteLine("2. Найти по фамилии");
        Console.WriteLine("3. Удалить");
        Console.WriteLine("4. Вывести список");
        Console.WriteLine("5. Закончить программу");
        Console.WriteLine("------------------------------");
        Console.WriteLine("Введите номер действия");
        whatToDo = Convert.ToInt32(Console.ReadLine());

        if (whatToDo == 5)
        {
            Console.WriteLine("Заканчиваем программу");
        }
        if(whatToDo == 1)
        {          
            Console.WriteLine("Введите ФИО");
           FIO.Add(Console.ReadLine());
            Console.WriteLine("Введите должность");
        job.Add(Console.ReadLine());
        }
        if (whatToDo == 2)
        {        
            Console.WriteLine("Введите фамилию для поиска");
            secondName=Console.ReadLine();
            for (int i = 0; i < job.Count; i++)
            {
                if ( FIO[i].IndexOf(secondName) == 0)
                {
                    Console.WriteLine((i + 1) + ". " + FIO[i] + " - " + job[i]);
                }
            }

        }
        if (whatToDo == 3)
        {
            Console.WriteLine("Введите ФИО для удаления");
            name = Console.ReadLine();
            Console.WriteLine("Введите Должность для удаления");
            jobNotArray = Console.ReadLine();
            for (int i = 0; i < job.Count; i++)
            {
                if (job[i].IndexOf(jobNotArray)==0 && FIO[i].IndexOf(name) == 0)
                {
                    job.RemoveAt(i);
                    FIO.RemoveAt(i);
                }
            }

        }
        if (whatToDo == 4)
        {
            Console.WriteLine(" Выводим сотрудниц");
            for (int i = 0; i <job.Count; i++)
            {
                Console.WriteLine((i+1) + ". " + FIO[i] + " - " + job[i]);
            }
       
        }
    }
    catch
    {
        whatToDo = 0;
    }
}
