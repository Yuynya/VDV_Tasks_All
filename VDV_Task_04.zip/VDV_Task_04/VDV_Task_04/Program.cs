﻿
int hpBOSS=1000, hpTraveler=750, mana=0, numberOfAtack;
Random rnd = new Random();
Console.WriteLine("Стой, Путница!");
Console.WriteLine("Перед тобой всесильная и могучая драконница! Чтобы пройти дальше тебе придёться сразиться со мной!");
Console.WriteLine("--------------");
Console.WriteLine("Делать нечего, вы принимаете вызов");
Console.WriteLine("--------------");
Console.WriteLine("Нажмите любую кнопку чтобы продолжить");
Console.ReadKey();
Console.Clear();
Console.WriteLine("Обучение");
Console.WriteLine("У вас есть пять способностей. Ими вы можете атаковать, защищаться или восстанавливать здоровье.");
Console.WriteLine("Некоторые способности требуют потратить МАНУ. МАНА может накаплаиваться со временем и  благодаря определённым действиям");
Console.WriteLine("Чтобы вызвать навык нажмите его порядковый номер. При неправильном вызове способности могут произойти неожиданные вещи. Будьте внимательны!");
Console.WriteLine("--------------");
Console.WriteLine("Нажмите любую кнопку чтобы продолжить");
Console.WriteLine("--------------");
Console.ReadKey();
Console.Clear();

while (hpBOSS>0 && hpTraveler>0)
{
   
    Console.WriteLine("--------------");
    Console.WriteLine("Ваше здоровье:{0}, ваша мана:{1}", hpTraveler, mana);
    Console.WriteLine("Здоровье противницы:{0}", hpBOSS);
    Console.WriteLine("--------------");
    Console.WriteLine("Атаковать водными плетьми(1): урон от 50-70 единиц здоровья");
    Console.WriteLine("Восстановить здоровье(2): восстановить 40-90 единиц здоровья");
    Console.WriteLine("Щит Тела(3): вы блокируете одну атаку и восполняете 4 еденицы маны");
    Console.WriteLine("Атаковать водным смерчем(4): урон от 100-170 единиц здоровья и потратить 15 маны");
    Console.WriteLine("Щит Тьмы(5): Блокировать атаку и восстановить  100 единиц здоровьяи потратить 10 маны");
    Console.WriteLine("Выберите действие, введя его номер");
    try
    {
        numberOfAtack = Convert.ToInt32(Console.ReadLine());
        if (numberOfAtack == 1)
        {
            AtackTraveler1(ref hpBOSS);
            AtackBoss(ref hpTraveler, ref mana);
        }
        if (numberOfAtack == 2)
        {
            Hill(ref hpTraveler);
            AtackBoss(ref hpTraveler,ref  mana);
        }
        if(numberOfAtack == 3)
        {
            Block(ref mana);
        }
        if(numberOfAtack==4 && mana >= 15)
        {
            AtackTraveler2(ref hpBOSS,ref  mana);
            AtackBoss(ref hpTraveler,ref mana);
        }
        if (numberOfAtack == 4 && mana < 15)
        {
            WrongMana(ref hpTraveler);
            AtackBoss(ref hpTraveler,ref mana);
        }
        if (numberOfAtack == 5 && mana >= 10)
        {
            BlockAndHill(ref hpTraveler,ref mana);
        }
        if (numberOfAtack == 5 && mana < 10)
        {
            WrongMana(ref hpTraveler);
        }
        if (numberOfAtack <= 0 ^ numberOfAtack>5)
        {
            Wrong(ref hpTraveler);
            AtackBoss(ref hpTraveler, ref mana);
        }
    }
    catch
    {
        Wrong(ref hpTraveler);
        AtackBoss(ref  hpTraveler, ref mana);
    }
}
if (hpBOSS <= 0) 

{
    Console.WriteLine("--------------");
    Console.WriteLine("--------------");
    Console.WriteLine("Вы победели!");
    Console.WriteLine("Вы можете продолжить своё приключение и рассказывать истории об этом поединке в тавернах под кружку сока!");
}
if (hpTraveler <= 0)
{
    Console.WriteLine("--------------");
    Console.WriteLine("--------------");
    Console.WriteLine("Вы пали героической смертью в бою со страшным врагом! Ваши потомки не забудут вашу жертву!");
}

void Hill(ref int hpTraveler)
{
    int hill = rnd.Next(40, 90);
    Console.WriteLine("Вы исполюзуете восстанавливаете {0} единиц здоровья", hill);

    hpTraveler= hpTraveler + hill;
    

}
void AtackBoss(ref int   hpTraveler, ref int mana)
{
    int atack = rnd.Next(60, 150);
    Console.WriteLine("Вас атакуют на {0} едениц здоровья!", atack);
    hpTraveler = hpTraveler - atack;
    mana = mana + 2;
   
}
void AtackTraveler1(ref int hpBOSS)
{
    int atack = rnd.Next(50, 70);
    Console.WriteLine("Вы атакуете Водными плетьми на {0} едениц урона!", atack);
    hpBOSS= hpBOSS- atack;
}
void Block(ref int mana)
{
    mana = mana +4;
    Console.WriteLine("Вы блокируете атаку!");
}
void AtackTraveler2(ref int hpBOSS, ref int mana)
{
    int atack = rnd.Next(100, 170);
    Console.WriteLine("Вы атакуете Водным смерчем на {0} единиц урона!", atack);
    hpBOSS=hpBOSS- atack;
    mana=mana-15;
}
void BlockAndHill(ref int hpTraveler, ref int mana)
{
    Console.WriteLine("Вы блокируете атаку и восстанавливаете 100 единиц здоровье, потратив 10 МАНЫ");
    mana = mana - 10;
    hpTraveler = hpTraveler +100;
}
void Wrong(ref int hpTraveler)
{
    int wrong = rnd.Next(1, 15);
    Console.WriteLine("Вы неправильно произнесли заклинание и теряете {0} единиц здоровья", wrong);

    hpTraveler = hpTraveler - wrong;

}
void WrongMana(ref int hpTraveler)
{
    int wrong = rnd.Next(4, 20);
    Console.WriteLine("У вас не хватает маны для заклинания, вы получаете откат и теряете {0} единиц здоровья", wrong);

    hpTraveler = hpTraveler - wrong;

}